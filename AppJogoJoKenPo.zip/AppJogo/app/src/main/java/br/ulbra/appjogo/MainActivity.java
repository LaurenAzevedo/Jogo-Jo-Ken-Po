package br.ulbra.appjogo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

import static kotlin.text.Typography.amp;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int pontuacao = 0;
    int pontuacaoApp = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnReiniciar = findViewById(R.id.btnReiniciar);
        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarJogo();
            }
        });
    }

    public void selecionadoPedra(View view) {
        this.opcaoSelecionado("pedraaaaa");
    }

    public void selecionadoPapel(View view) {
        this.opcaoSelecionado("paperr");
    }

    public void selecionadoTesoura(View view) {
        this.opcaoSelecionado("tesouraaaaa");
    }


    public void opcaoSelecionado(String opcaoSelecionada) {

        ImageView imagem = findViewById(R.id.imagem);
        TextView txtResultado = findViewById(R.id.txtResultado);
        String opcoes[] = {"pedraaaaa", "paperr ", "tesouraaaaa"};
        String opcaoApp = opcoes[new Random().nextInt(3)];
        switch (opcaoApp) {
            case "pedraaaaa":
                imagem.setImageResource(R.drawable.pedraaaaa);
                break;
            case "paperr":
                imagem.setImageResource(R.drawable.paperr);
                break;
            case "tesouraaaaa":
                imagem.setImageResource(R.drawable.tesouraaaaa);
                break;

        }
        if ((opcaoApp.equals("tesouraaaaa") && opcaoSelecionada.equals("pedraaaaa")) || (opcaoApp.equals("paperr") && opcaoSelecionada.equals("pedraaaaa")) || (opcaoApp.equals("pedraaaaa") && opcaoSelecionada.equals("tesouraaaaa"))) {
            txtResultado.setText("Resultado: Você PERDEU... :");

            pontuacaoApp ++;
            atualizarPlacar();

        } else if ((opcaoSelecionada.equals("tesouraaaaa") && opcaoApp.equals("paperr")) || (opcaoSelecionada.equals("paperr") && opcaoApp.equals("pedraaaaa")) || (opcaoSelecionada.equals("pedraaaaa") && opcaoApp.equals("tesouraaaaa"))) {
            txtResultado.setText("Resultado: Você GANHOU...");

            pontuacao ++;
            atualizarPlacar();
        } else {
            txtResultado.setText("Resultado: Vocês EMPATARAM...");
            atualizarPlacar();
        }
    }
    public void atualizarPlacar (){

    TextView txtPlacar = findViewById(R.id.txtPlacar);
    txtPlacar.setText("Jogador:  " + pontuacao + "       Aplicativo: " + pontuacaoApp);
    }
    public void reiniciarJogo (){
        atualizarPlacar();
        pontuacao = 0;
        pontuacaoApp = 0;
     ImageView imagem = findViewById(R.id.imagem);
     imagem.setImageResource(android.R.color.transparent);
         }
}

